package ts;

public class QuestionTest{
	public static void main(String[] args) {
		QuestionInventory Run = new QuestionInventory();
		Run.inputAnswer();
	}
}


