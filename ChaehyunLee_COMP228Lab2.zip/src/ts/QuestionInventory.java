package ts;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class QuestionInventory {
	Boolean correct;
	int score=0;
	int total;
	Scanner input=new Scanner(System.in);
	Random rnd = new Random();

	public Question[] simulateQuestion() {
		
        String q1 = JOptionPane.showInputDialog("Who is the best professor?\n1.You\n2.Spiderman\n3.Emma Watson\n4.Albus Dumbledore");
        System.out.println(q1);
        String q2 = JOptionPane.showInputDialog("What is the capital of Japan?\n1.Kobe\n2.Osaka\n3.Kyoto\n4.Tokyo");
        System.out.println(q2);
        String q3 = JOptionPane.showInputDialog("What is the best college in Canada?\n1.Seneca College\n2.Humber College\n3.Centennial College\n4.George Brown College");
        System.out.println(q3);
        String q4 = JOptionPane.showInputDialog("What is the capital city of Canada?\n1.Toronto\n2.Vancuver\n3.Quebec\n4.Ottawa");
        System.out.println(q4);
        String q5 = JOptionPane.showInputDialog("What is the capital of the United States?\n1.Florida\n2.New York\n3.Washington DC\n4.Chicago");
        System.out.println(q5);
		
		
		ArrayList<Question> questions = new ArrayList<Question>();
		questions.add(new Question("Who is the best professor?", "1.You", "2.Spiderman", "3.Emma Watson", "4.Albus Dumbledore", 1));
		questions.add(new Question("What is the capital of Japan?", "1.Kobe", "2.Osaka", "3.Kyoto", "4.Tokyo", 4));
		questions.add(new Question("What is the best college in Canada?", "1.Seneca College", "2.Humber College", "3.Centennial College", "4.George Brown College", 3));
		questions.add(new Question("What is the capital city of Canada?", "1.Toronto", "2.Vancuver", "3.Quebec", "4.Ottawa", 4));
		questions.add(new Question("What is the capital of the United States?", "1. Washington DC", "2. New York", "3.Florida", "4.Chicago", 1));
		
		Question[] questionRun = new Question[5];
		Question temp = new Question();
		boolean exists = false;
		for (int i = 0; i < 5; i++) {
			do {
				temp = questions.get(rnd.nextInt(5));
				for (int j = 0; j < questionRun.length; j++) {
					if (questionRun[j] != null) {
						if (questionRun[j].question == temp.question) {
							exists = true;
						} 
						else {
							exists = false;
						}
					}
				}
			} while (exists == true);
			questionRun[i] = temp;
		}
		return questionRun;
	}
	
	public boolean CheckAnswer(Question question, int yourAnswer) 
	{
		if (question.correctAnswer == yourAnswer) {
			correct = true;
			score++;
		}
		else {
			correct = false;
		}
		return correct;
	}
	
	public void generateMessage(boolean result) {
		if (result) {
			int message = rnd.nextInt(4);
			switch (message) {
			case 0:
				System.out.println("Excellent");
				break;
			case 1:
				System.out.println("Good!");
				break;
			default:
				System.out.println("Nice!");
			}
		}
		else {
			System.out.println("No");
			}
		}
	
	public void inputAnswer()
	{
		int yourAnswer;
		Question[] questions = simulateQuestion();
		for (int i = 0; i < questions.length; i++) {
			System.out.println(questions[i].toString());
			System.out.print("Select answer: ");
			yourAnswer = input.nextInt();
			generateMessage(CheckAnswer(questions[i], yourAnswer));
			System.out.printf("Your score is %d out of 5\n",score);
			total=(int)(score*100)/5;
			System.out.printf("Your  percentage of correct answers is %d percent",total);
		}
	}



	}
	






