package ts;

public class Question {
	
	String question;
	String answer1;
	String answer2;
	String answer3;
	String answer4;
	int correctAnswer;
	
	public Question() {}
	
	public Question(String quest, String an1, String an2, String an3, String an4, int correct) {
		question = quest;
		answer1 = an1;
		answer2 = an2;
		answer3 = an3;
		answer4 = an4;
		correctAnswer = correct;
	}

	public String toString() {
		return "\n\n"+question+"\n"+answer1+"\n"+answer2+"\n"+answer3+"\n"+answer4;
	}
}
