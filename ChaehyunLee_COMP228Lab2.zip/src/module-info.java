module ChaehyunLee_COMP228Lab2 {
	requires java.desktop;
}